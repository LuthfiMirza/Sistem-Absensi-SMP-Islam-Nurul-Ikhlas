<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'theme' => '',
    'column' => null,
    'inline' => null,
    'inputText' => null
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'theme' => '',
    'column' => null,
    'inline' => null,
    'inputText' => null
]); ?>
<?php foreach (array_filter(([
    'theme' => '',
    'column' => null,
    'inline' => null,
    'inputText' => null
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <?php if(filled($inputText)): ?>
        <div class="<?php if(!$inline): ?> pt-2 p-2 <?php endif; ?>">
            <?php if(!$inline): ?>
                <label><?php echo e($inputText['label']); ?></label>
            <?php endif; ?>
            <div class="<?php if($inline): ?> flex flex-col <?php else: ?> flex flex-row <?php endif; ?>">
                <div class="<?php if(!$inline): ?> pl-0 pt-1 pr-3 <?php endif; ?>">
                    <div class="relative">
                        <select id="input_text_options" class="power_grid <?php echo e($theme->selectClass); ?>"
                                wire:input.lazy="filterInputTextOptions('<?php echo e($inputText['field']); ?>', $event.target.value, '<?php echo e($inputText['label']); ?>')">
                            <option value="contains"><?php echo e(trans('livewire-powergrid::datatable.input_text_options.contains')); ?></option>
                            <option value="contains_not"><?php echo e(trans('livewire-powergrid::datatable.input_text_options.contains_not')); ?></option>
                            <option value="is"><?php echo e(trans('livewire-powergrid::datatable.input_text_options.is')); ?></option>
                            <option value="is_not"><?php echo e(trans('livewire-powergrid::datatable.input_text_options.is_not')); ?></option>
                            <option value="starts_with"><?php echo e(trans('livewire-powergrid::datatable.input_text_options.starts_with')); ?></option>
                            <option value="ends_with"><?php echo e(trans('livewire-powergrid::datatable.input_text_options.ends_with')); ?></option>
                        </select>
                        <div class="<?php echo e($theme->relativeDivClass); ?>">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'livewire-powergrid::components.icons.down','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('livewire-powergrid::icons.down'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>
                    </div>
                    <input
                        data-id="<?php echo e($inputText['field']); ?>"
                        wire:input.lazy="filterInputText('<?php echo e($inputText['field']); ?>', $event.target.value, '<?php echo e($inputText['label']); ?>')"
                        type="text"
                        class="power_grid <?php echo e($theme->inputClass); ?>"
                        placeholder="<?php echo e($column->title); ?>">
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\projek 1\absensi-project-main\resources\views/vendor/livewire-powergrid/components/filters/input-text.blade.php ENDPATH**/ ?>