<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'actions' => null,
    'theme' => null,
    'row' => null
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'actions' => null,
    'theme' => null,
    'row' => null
]); ?>
<?php foreach (array_filter(([
    'actions' => null,
    'theme' => null,
    'row' => null
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="w-full md:w-auto">
    <?php if($row === ''): ?>
        <div class="sm:flex sm:flex-row">
            <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="sm:mr-2 mb-2 w-auto">

                    <?php if($action->event !== ''): ?>
                        <button wire:click='$emit("<?php echo e($action->event); ?>", <?php echo json_encode($action->param, 15, 512) ?>)'
                                class="<?php echo e(filled($action->class) ? $action->class : $theme->actions->headerBtnClass); ?>">
                            <?php echo $action->caption; ?>

                        </button>

                    <?php elseif($action->view !== ''): ?>
                        <button wire:click='$emit("openModal", "<?php echo e($action->view); ?>", <?php echo json_encode($action->param, 15, 512) ?>)'
                                class="<?php echo e(filled($action->class) ? $action->class : $theme->actions->headerBtnClass); ?>">
                            <?php echo $action->caption; ?>

                        </button>

                    <?php else: ?>
                        <form <?php if($action->method !== 'delete'): ?> target="_blank"
                              <?php endif; ?> action="<?php echo e(route($action->route, $action->param)); ?>" method="post">
                            <?php echo method_field($action->method); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="<?php echo e(filled($action->class) ? $action->class : $theme->actions->headerBtnClass); ?>">
                                <?php echo $action->caption; ?>

                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <?php if(isset($actions) && count($actions) && $row !== ''): ?>
        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td class="<?php echo e($theme->actions->tdBodyClass ?? $theme->table->tdBodyClass); ?>"
                style="<?php echo e($theme->actions->tdBodyClass ?? $theme->table->tdBodyStyle); ?>">
                <?php
                    $parameters = [];
                    foreach ($action->param as $param => $value) {
                       $parameters[$param] = $row->{$value};
                    }
                ?>

                <?php if($action->event !== ''): ?>
                    <button wire:click='$emit("<?php echo e($action->event); ?>", <?php echo json_encode($parameters, 15, 512) ?>)'
                            class="<?php echo e(filled( $action->class) ? $action->class : $theme->actions->btnClass); ?>">
                        <?php echo $action->caption ?? ''; ?>

                    </button>

                <?php elseif($action->view !== ''): ?>
                    <button wire:click='$emit("openModal", "<?php echo e($action->view); ?>", <?php echo json_encode($parameters, 15, 512) ?>)'
                            class="<?php echo e(filled( $action->class) ? $action->class : $theme->actions->btnClass); ?>">
                        <?php echo $action->caption ?? ''; ?>

                    </button>

                <?php else: ?>
                    <form <?php if($action->method !== 'delete'): ?> target="_blank"
                          <?php endif; ?> action="<?php echo e(route($action->route, $parameters)); ?>" method="post">
                        <?php echo method_field($action->method); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="<?php echo e(filled( $action->class) ? $action->class : $theme->actions->btnClass); ?>">
                            <?php echo $action->caption ?? ''; ?>

                        </button>
                    </form>
                <?php endif; ?>
            </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\projek 1\absensi-project-main\resources\views/vendor/livewire-powergrid/components/actions.blade.php ENDPATH**/ ?>