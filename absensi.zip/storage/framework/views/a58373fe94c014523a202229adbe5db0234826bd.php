<?php $__env->startSection('buttons'); ?>
<div class="btn-toolbar mb-2 mb-md-0">
    <div>
        <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-sm btn-primary">
            <i class="fas fa-plus-circle me-1"></i>
            Tambah Data Guru/Karyawan
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('simple-employee-table', [])->html();
} elseif ($_instance->childHasBeenRendered('ecPefxq')) {
    $componentId = $_instance->getRenderedChildComponentId('ecPefxq');
    $componentTag = $_instance->getRenderedChildComponentTagName('ecPefxq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ecPefxq');
} else {
    $response = \Livewire\Livewire::mount('simple-employee-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('ecPefxq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projek 1\absensi-project-main\resources\views/employees/index.blade.php ENDPATH**/ ?>