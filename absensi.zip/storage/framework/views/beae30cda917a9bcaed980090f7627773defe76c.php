<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'theme' => '',
    'inline' => null,
    'date' => null
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'theme' => '',
    'inline' => null,
    'date' => null
]); ?>
<?php foreach (array_filter(([
    'theme' => '',
    'inline' => null,
    'date' => null
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <?php
        $customConfig = [];
        if (isset($date['config'])) {
            foreach ($date['config'] as $key => $value) {
                $customConfig[$key] = $value;
            }
        }
    ?>

    <div class="<?php echo e($theme->divClassNotInline); ?>" <?php if($inline): ?>  <?php endif; ?>>

        <?php if(!$inline): ?>
            <label for="input_<?php echo $date['field']; ?>"
                   class="text-gray-700 dark:text-gray-300"><?php echo $date['label']; ?></label>
        <?php endif; ?>
        <input id="input_<?php echo $date['field']; ?>"
               data-field="<?php echo $date['dataField']; ?>"
               data-key="enabledFilters.date_picker.<?php echo $date['dataField']; ?>"
               class="power_grid range_input_<?php echo $date['field']; ?> <?php echo e($theme->inputClass); ?>"
               type="text"
               placeholder="<?php echo e(trans('livewire-powergrid::datatable.placeholders.select')); ?>"
                wire:model="filters.input_date_picker.<?php echo $date['dataField']; ?>"
               wire:ignore
        >
    </div>
    <?php $__env->startPush('power_grid_scripts'); ?>
        <script type="application/javascript">
            flatpickr(document.getElementsByClassName('range_input_<?php echo $date['field']; ?>'), {
                    mode: 'range',
                    defaultHour: 0,
                    ...<?php echo json_encode(config('livewire-powergrid.plugins.flat_piker.locales.'.app()->getLocale()), 15, 512) ?>,
                    <?php if(isset($customConfig['only_future'])): ?>
                    minDate: 'today',
                    <?php endif; ?>
                        <?php if(isset($customConfig['no_weekends']) === true): ?>
                    disable: [
                        function (date) {
                            return (date.getDay() === 0 || date.getDay() === 6);
                        }
                    ],
                    <?php endif; ?>
                    ...<?php echo json_encode($customConfig, 15, 512) ?>,
                    onClose: function (selectedDates, dateStr, instance) {
                        if (selectedDates.length > 0) {
                            window.livewire.emit('eventChangeDatePiker', {
                                selectedDates: selectedDates,
                                field: instance._input.attributes['data-field'].value,
                                values: instance._input.attributes['data-key'].value,
                                label: '<?php echo e($date['label']); ?>'
                            });
                        }
                    }
                }
            );
        </script>
    <?php $__env->stopPush(); ?>

</div>

<?php /**PATH C:\xampp\htdocs\projek 1\absensi-project-main\resources\views/vendor/livewire-powergrid/components/filters/date-picker.blade.php ENDPATH**/ ?>