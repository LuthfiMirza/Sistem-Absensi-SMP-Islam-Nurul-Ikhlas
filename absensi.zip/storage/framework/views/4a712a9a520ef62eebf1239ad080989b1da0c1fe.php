<?php $__env->startPush('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('base'); ?>

<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="main-content">
    <div class="container-fluid px-4">
        <!-- Page Header -->
        <div class="page-header d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center">
            <div>
                <h1 class="h3 mb-0 text-gray-800"><?php echo e($title); ?></h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a></li>
                        <?php if(!request()->routeIs('dashboard.*')): ?>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e($title); ?></li>
                        <?php endif; ?>
                    </ol>
                </nav>
            </div>
            <div class="btn-toolbar mb-2 mb-md-0">
                <?php echo $__env->yieldContent('buttons'); ?>
            </div>
        </div>

        <!-- Page Content -->
        <div class="content-wrapper">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</main>

<!-- Profile Modal for Employees/Teachers -->
<?php if(auth()->user()->isUser()): ?>
    <?php echo $__env->make('partials.profile-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projek 1\absensi-project-main\resources\views/layouts/app.blade.php ENDPATH**/ ?>