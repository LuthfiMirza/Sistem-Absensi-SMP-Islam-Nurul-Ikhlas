<div class="dt--top-section">
    <div class="row">

        <div class="col-12 col-sm-6 d-flex justify-content-sm-start justify-content-center">

            <?php echo $__env->make($theme->base. ''.$theme->name.'.export', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php if ($__env->exists($theme->base. ''.$theme->name.'.toggle-columns')) echo $__env->make($theme->base. ''.$theme->name.'.toggle-columns', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make('livewire-powergrid::components.frameworks.bootstrap5.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
        <div class="col-12 col-sm-6 d-flex justify-content-sm-end justify-content-center mt-sm-0 mt-3">

            <?php echo $__env->make($theme->base. ''.$theme->name.'.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

    </div>
</div>

<div class="col-md-12 d-flex" style="margin-top: 5px">
<?php $__currentLoopData = $enabledFilters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div wire:click.prevent="clearFilter('<?php echo e($field); ?>')" style="cursor: pointer; padding-right: 4px">
        <span class="badge rounded-pill bg-light text-dark"><?php echo e($filter['label']); ?>

         <svg width="10" stroke="currentColor" fill="none" viewBox="0 0 8 8">
            <path stroke-linecap="round" stroke-width="1.5" d="M1 1l6 6m0-6L1 7"/>
        </svg>
        </span>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\projek 1\absensi-project-main\resources\views/vendor/livewire-powergrid/components\frameworks\bootstrap5\header.blade.php ENDPATH**/ ?>