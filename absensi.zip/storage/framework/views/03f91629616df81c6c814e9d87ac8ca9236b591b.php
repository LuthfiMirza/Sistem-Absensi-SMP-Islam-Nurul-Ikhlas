<?php $__env->startSection('buttons'); ?>
<div class="btn-toolbar mb-2 mb-md-0">
    <div>
        <a href="<?php echo e(route('attendances.create')); ?>" class="btn btn-sm btn-primary">
            <i class="fas fa-plus-circle me-1"></i>
            Tambah Data Absensi
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('simple-attendance-table', [])->html();
} elseif ($_instance->childHasBeenRendered('PoELmKg')) {
    $componentId = $_instance->getRenderedChildComponentId('PoELmKg');
    $componentTag = $_instance->getRenderedChildComponentTagName('PoELmKg');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PoELmKg');
} else {
    $response = \Livewire\Livewire::mount('simple-attendance-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('PoELmKg', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projek 1\absensi-project-main\resources\views/attendances/index.blade.php ENDPATH**/ ?>