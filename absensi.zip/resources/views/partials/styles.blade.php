{{-- Bootstrap 5.2 CSS --}}
<link rel="stylesheet" href="{{ asset('bootstrap5/css/bootstrap.min.css') }}">
<!----===== Boxicons CSS ===== -->
{{--
<link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'> --}}
{{-- Main CSS --}}
<link rel="stylesheet" href="{{ asset('css/main.css') }}">
{{-- Livewire CSS --}}
@livewireStyles