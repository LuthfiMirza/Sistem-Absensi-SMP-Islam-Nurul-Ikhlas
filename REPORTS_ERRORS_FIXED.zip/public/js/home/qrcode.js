// QR Code Scanner Implementation
let html5QrcodeScanner = null;
let isScanning = false;

const QRCodeScannerModal = document.getElementById("qrcode-scanner-modal");

if (QRCodeScannerModal) {
    QRCodeScannerModal.addEventListener("show.bs.modal", async (event) => {
        const isEnter = event.relatedTarget.dataset.isEnter == "1";
        
        // Clear any existing scanner
        if (html5QrcodeScanner) {
            try {
                await html5QrcodeScanner.clear();
            } catch (error) {
                console.log("Scanner already cleared");
            }
        }

        // Success callback
        function onScanSuccess(decodedText, decodedResult) {
            if (isScanning) return; // Prevent multiple scans
            
            isScanning = true;
            console.log(`QR Code detected: ${decodedText}`);
            
            // Stop scanner
            html5QrcodeScanner.clear().then(() => {
                // Close modal
                const modal = bootstrap.Modal.getInstance(QRCodeScannerModal);
                modal.hide();
                
                // Handle presence
                handlePresence(isEnter ? enterPresenceUrl : outPresenceUrl, decodedText);
            }).catch(err => {
                console.error("Error stopping scanner:", err);
                handlePresence(isEnter ? enterPresenceUrl : outPresenceUrl, decodedText);
            });
        }

        // Error callback (optional)
        function onScanFailure(error) {
            // Handle scan failure - usually not needed for user feedback
            // console.warn(`QR Code scan error: ${error}`);
        }

        // Enhanced scanner configuration
        const config = {
            fps: 15, // Increased FPS for better detection
            qrbox: { 
                width: Math.min(300, window.innerWidth - 100), 
                height: Math.min(300, window.innerWidth - 100) 
            },
            aspectRatio: 1.0,
            disableFlip: false, // Allow flipped QR codes
            rememberLastUsedCamera: true,
            supportedScanTypes: [Html5QrcodeScanType.SCAN_TYPE_CAMERA],
            formatsToSupport: [Html5QrcodeSupportedFormats.QR_CODE],
            experimentalFeatures: {
                useBarCodeDetectorIfSupported: true
            }
        };

        // Create new scanner
        html5QrcodeScanner = new Html5QrcodeScanner("reader", config, false);
        
        // Start scanning
        html5QrcodeScanner.render(onScanSuccess, onScanFailure);
        
        // Reset scanning flag
        isScanning = false;
        
        // Add instructions
        setTimeout(() => {
            const readerElement = document.getElementById("reader");
            if (readerElement) {
                // Add custom styling for better visibility
                const scanRegion = readerElement.querySelector('#qr-shaded-region');
                if (scanRegion) {
                    scanRegion.style.border = '3px solid #007bff';
                    scanRegion.style.borderRadius = '10px';
                }
            }
        }, 1000);
    });

    // Clean up when modal is hidden
    QRCodeScannerModal.addEventListener("hidden.bs.modal", async () => {
        if (html5QrcodeScanner) {
            try {
                await html5QrcodeScanner.clear();
                html5QrcodeScanner = null;
            } catch (error) {
                console.log("Scanner cleanup error:", error);
            }
        }
        isScanning = false;
    });
}

// Handle presence submission
async function handlePresence(baseurl, code) {
    try {
        // Show loading
        showToast('info', 'Memproses absensi...', 'QR Code Absensi');
        
        const response = await fetch(baseurl, {
            method: "POST",
            headers: {
                "X-Requested-With": "XMLHttpRequest",
                "Content-Type": "application/x-www-form-urlencoded",
                "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: new URLSearchParams({ code: code })
        });

        const data = await response.json();
        
        if (data.success) {
            showToast('success', data.message, 'Absensi Berhasil');
            // Reload page after short delay
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } else {
            showToast('error', data.message || 'Terjadi kesalahan saat absensi', 'Absensi Gagal');
        }
    } catch (error) {
        console.error('Error handling presence:', error);
        showToast('error', 'Terjadi kesalahan koneksi. Silakan coba lagi.', 'Error');
    }
}

// Simple toast notification function
function showToast(type, message, title = '') {
    // Create toast element
    const toastContainer = document.querySelector('.toast-container') || createToastContainer();
    
    const toastId = 'toast-' + Date.now();
    const bgClass = type === 'success' ? 'bg-success' : type === 'error' ? 'bg-danger' : 'bg-info';
    
    const toastHTML = `
        <div id="${toastId}" class="toast ${bgClass} text-white" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header ${bgClass} text-white border-0">
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'} me-2"></i>
                <strong class="me-auto">${title}</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>
    `;
    
    toastContainer.insertAdjacentHTML('beforeend', toastHTML);
    
    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, { delay: 4000 });
    toast.show();
    
    // Remove toast element after it's hidden
    toastElement.addEventListener('hidden.bs.toast', () => {
        toastElement.remove();
    });
}

function createToastContainer() {
    const container = document.createElement('div');
    container.className = 'toast-container position-fixed top-0 end-0 p-3';
    container.style.zIndex = '9999';
    document.body.appendChild(container);
    return container;
}

// Debug function for testing
window.testQRCode = function(code) {
    console.log('Testing QR Code:', code);
    handlePresence(enterPresenceUrl, code);
};
