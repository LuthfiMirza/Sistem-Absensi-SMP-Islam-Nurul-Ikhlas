// Simple test function to bypass modal
function testUpdatePermissionStatus(permissionId, action) {
    console.log('Test function called with:', permissionId, action);
    
    // Create a simple form and submit it directly
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = `/permissions/${permissionId}/status`;
    
    // Add CSRF token
    const csrfToken = document.querySelector('meta[name="csrf-token"]');
    if (csrfToken) {
        const csrfInput = document.createElement('input');
        csrfInput.type = 'hidden';
        csrfInput.name = '_token';
        csrfInput.value = csrfToken.getAttribute('content');
        form.appendChild(csrfInput);
    }
    
    // Add action input
    const actionInput = document.createElement('input');
    actionInput.type = 'hidden';
    actionInput.name = 'action';
    actionInput.value = action;
    form.appendChild(actionInput);
    
    // Add to body and submit
    document.body.appendChild(form);
    
    console.log('Submitting form to:', form.action);
    console.log('With action:', action);
    
    form.submit();
}