// Simple permission status update without modal
function simpleUpdatePermissionStatus(permissionId, action) {
    console.log('Simple update called:', permissionId, action);
    
    // Create form dynamically
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = `/permissions/${permissionId}/status`;
    
    // Add CSRF token
    const csrfToken = document.querySelector('meta[name="csrf-token"]');
    if (csrfToken) {
        const csrfInput = document.createElement('input');
        csrfInput.type = 'hidden';
        csrfInput.name = '_token';
        csrfInput.value = csrfToken.getAttribute('content');
        form.appendChild(csrfInput);
    }
    
    // Add action
    const actionInput = document.createElement('input');
    actionInput.type = 'hidden';
    actionInput.name = 'action';
    actionInput.value = action;
    form.appendChild(actionInput);
    
    // Add rejection reason if rejecting
    if (action === 'reject') {
        const reason = prompt('Masukkan alasan penolakan:');
        if (!reason || reason.trim() === '') {
            alert('Alasan penolakan harus diisi!');
            return;
        }
        const reasonInput = document.createElement('input');
        reasonInput.type = 'hidden';
        reasonInput.name = 'rejection_reason';
        reasonInput.value = reason;
        form.appendChild(reasonInput);
    }
    
    // Confirm action
    const confirmMessage = action === 'accept' ? 'Terima izin ini?' : 'Tolak izin ini?';
    if (!confirm(confirmMessage)) {
        return;
    }
    
    // Submit form
    document.body.appendChild(form);
    form.submit();
}