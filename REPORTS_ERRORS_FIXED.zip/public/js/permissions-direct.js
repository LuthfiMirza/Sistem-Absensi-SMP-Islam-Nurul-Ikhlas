// Direct form submission without modal - for testing
function directUpdatePermissionStatus(permissionId, action) {
    console.log('Direct update called:', permissionId, action);
    
    // Confirm action
    const confirmMessage = action === 'accept' ? 
        'Apakah Anda yakin ingin MENERIMA izin ini?' : 
        'Apakah Anda yakin ingin MENOLAK izin ini?';
    
    if (!confirm(confirmMessage)) {
        return;
    }
    
    // Get rejection reason if needed
    let rejectionReason = '';
    if (action === 'reject') {
        rejectionReason = prompt('Masukkan alasan penolakan:');
        if (!rejectionReason || rejectionReason.trim() === '') {
            alert('Alasan penolakan harus diisi!');
            return;
        }
    }
    
    // Create form
    const form = document.createElement('form');
    form.method = 'POST';
    form.setAttribute('action', `/permissions/${permissionId}/status`);
    
    // Add CSRF token
    const csrfToken = document.querySelector('meta[name="csrf-token"]');
    if (csrfToken) {
        const csrfInput = document.createElement('input');
        csrfInput.type = 'hidden';
        csrfInput.name = '_token';
        csrfInput.value = csrfToken.getAttribute('content');
        form.appendChild(csrfInput);
    } else {
        // Try to get CSRF from existing form
        const existingForm = document.getElementById('statusForm');
        if (existingForm) {
            const existingCsrf = existingForm.querySelector('input[name="_token"]');
            if (existingCsrf) {
                const csrfInput = document.createElement('input');
                csrfInput.type = 'hidden';
                csrfInput.name = '_token';
                csrfInput.value = existingCsrf.value;
                form.appendChild(csrfInput);
            }
        }
    }
    
    // Add action
    const actionInput = document.createElement('input');
    actionInput.type = 'hidden';
    actionInput.name = 'action';
    actionInput.value = action;
    form.appendChild(actionInput);
    
    // Add rejection reason if needed
    if (action === 'reject' && rejectionReason) {
        const reasonInput = document.createElement('input');
        reasonInput.type = 'hidden';
        reasonInput.name = 'rejection_reason';
        reasonInput.value = rejectionReason;
        form.appendChild(reasonInput);
    }
    
    // Add to body and submit
    document.body.appendChild(form);
    
    console.log('Submitting form to:', form.getAttribute('action'));
    console.log('Form data:', {
        action: action,
        rejection_reason: rejectionReason || 'N/A'
    });
    
    form.submit();
}