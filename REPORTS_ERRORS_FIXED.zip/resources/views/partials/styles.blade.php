{{-- Bootstrap 5.2 CSS --}}
<link rel="stylesheet" href="{{ asset('bootstrap5/css/bootstrap.min.css') }}">
<!----===== Boxicons CSS ===== -->
{{--
<link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'> --}}
{{-- SweetAlert2 CSS --}}
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
{{-- Main CSS --}}
<link rel="stylesheet" href="{{ asset('css/main.css') }}">
{{-- Livewire CSS --}}
@livewireStyles