
<link rel="stylesheet" href="<?php echo e(asset('bootstrap5/css/bootstrap.min.css')); ?>">
<!----===== Boxicons CSS ===== -->


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

<link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">

<?php echo \Livewire\Livewire::styles(); ?><?php /**PATH C:\xampp\htdocs\projek 1\absensi-project-main\resources\views/partials/styles.blade.php ENDPATH**/ ?>