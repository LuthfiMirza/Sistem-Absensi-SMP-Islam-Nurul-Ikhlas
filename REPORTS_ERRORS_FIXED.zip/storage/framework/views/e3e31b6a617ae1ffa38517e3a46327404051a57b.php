<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block sidebar collapse">
    <div class="position-sticky pt-3">
        <!-- User Profile Section -->
        <div class="user-profile mb-4 px-3">
            <div class="d-flex align-items-center">
                <div class="profile-img me-3">
                    <img src="/assets/img/profile.png" alt="Profile" class="rounded-circle" width="40" height="40">
                </div>
                <div class="profile-info">
                    <h6 class="mb-0 text-white"><?php echo e(auth()->user()->name); ?></h6>
                    <small class="text-light opacity-75"><?php echo e(auth()->user()->role->name); ?></small>
                </div>
            </div>
        </div>

        <!-- Navigation Menu -->
        <ul class="nav flex-column px-2">
            <?php if(auth()->user()->isAdmin() or auth()->user()->isOperator()): ?>
                <!-- Admin/Operator Menu -->
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo e(request()->routeIs('dashboard.*') ? 'active' : ''); ?>" 
                       href="<?php echo e(route('dashboard.index')); ?>">
                        <i class="fas fa-tachometer-alt me-3"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo e(request()->routeIs('positions.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('positions.index')); ?>">
                        <i class="fas fa-sitemap me-3"></i>
                        <span>Divisi Pegawai</span>
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo e(request()->routeIs('employees.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('employees.index')); ?>">
                        <i class="fas fa-users me-3"></i>
                        <span>Pegawai</span>
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo e(request()->routeIs('attendances.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('attendances.index')); ?>">
                        <i class="fas fa-calendar-check me-3"></i>
                        <span>Absensi</span>
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo e(request()->routeIs('presences.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('presences.index')); ?>">
                        <i class="fas fa-chart-line me-3"></i>
                        <span>Data Kehadiran</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(auth()->user()->isUser()): ?>
                <!-- Guru/Karyawan Menu -->
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo e(request()->routeIs('home.index') ? 'active' : ''); ?>" 
                       href="<?php echo e(route('home.index')); ?>">
                        <i class="fas fa-home me-3"></i>
                        <span>Beranda</span>
                    </a>
                </li>
                
                <!-- Absensi Section -->
                <li class="nav-item mb-2">
                    <div class="nav-section-header px-3 py-2">
                        <small class="text-light opacity-75 fw-bold">ABSENSI</small>
                    </div>
                </li>
                
                <?php
                    // Get available attendances for current user
                    $availableAttendances = \App\Models\Attendance::whereHas('positions', function($query) {
                        $query->where('position_id', auth()->user()->position_id);
                    })->get();
                ?>
                
                <?php $__empty_1 = true; $__currentLoopData = $availableAttendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="nav-item mb-1">
                        <a class="nav-link <?php echo e(request()->routeIs('home.show') && request()->route('attendance')?->id == $attendance->id ? 'active' : ''); ?>"
                           href="<?php echo e(route('home.show', $attendance->id)); ?>">
                            <i class="fas fa-calendar-day me-3"></i>
                            <span><?php echo e($attendance->title); ?></span>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="nav-item mb-1">
                        <div class="nav-link text-muted">
                            <i class="fas fa-info-circle me-3"></i>
                            <span>Tidak ada absensi tersedia</span>
                        </div>
                    </li>
                <?php endif; ?>
        
                <!-- Quick Actions Section -->
                <li class="nav-item mb-2 mt-3">
                    <div class="nav-section-header px-3 py-2">
                        <small class="text-light opacity-75 fw-bold">AKSI CEPAT</small>
                    </div>
                </li>
                
                <?php if($availableAttendances->count() > 0): ?>
                    <?php $firstAttendance = $availableAttendances->first(); ?>
                    
                    <li class="nav-item mb-1">
                        <a class="nav-link <?php echo e(request()->routeIs('home.permission') ? 'active' : ''); ?>"
                           href="<?php echo e(route('home.permission', $firstAttendance->id)); ?>">
                            <i class="fas fa-file-medical me-3"></i>
                            <span>Ajukan Izin</span>
                        </a>
                    </li>
                    
                    <?php if($firstAttendance->code): ?>
                        <li class="nav-item mb-1">
                            <a class="nav-link" 
                               href="<?php echo e(route('presences.qrcode', ['code' => $firstAttendance->code])); ?>"
                               target="_blank">
                                <i class="fas fa-qrcode me-3"></i>
                                <span>QR Code Absensi</span>
                                <i class="fas fa-external-link-alt ms-2 small"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

                <!-- Izin Section -->
                <li class="nav-item mb-2 mt-3">
                    <div class="nav-section-header px-3 py-2">
                        <small class="text-light opacity-75 fw-bold">IZIN</small>
                    </div>
                </li>
                
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo e(request()->routeIs('my-permissions.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('my-permissions.index')); ?>">
                        <i class="fas fa-list me-3"></i>
                        <span>Data Izin Saya</span>
                    </a>
                </li>
                
                <?php if(auth()->user()->isKaryawan()): ?>
                    <li class="nav-item mb-1">
                        <a class="nav-link <?php echo e(request()->routeIs('my-permissions.create') ? 'active' : ''); ?>"
                           href="<?php echo e(route('my-permissions.create')); ?>">
                            <i class="fas fa-plus me-3"></i>
                            <span>Ajukan Izin Baru</span>
                        </a>
                    </li>
                <?php endif; ?>

                <!-- Profile Section -->
                <li class="nav-item mb-2 mt-3">
                    <div class="nav-section-header px-3 py-2">
                        <small class="text-light opacity-75 fw-bold">PROFIL</small>
                    </div>
                </li>
                
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo e(request()->routeIs('profile.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('profile.index')); ?>">
                        <i class="fas fa-user me-3"></i>
                        <span>Profil Saya</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(auth()->user()->isAdmin() or auth()->user()->isOperator()): ?>
                <!-- Admin Menu Additions -->
                
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo e(request()->routeIs('permissions.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('permissions.index')); ?>">
                        <i class="fas fa-file-signature me-3"></i>
                        <span>Kelola Izin</span>
                    </a>
                </li>
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo e(request()->routeIs('reports.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('reports.index')); ?>">
                        <i class="fas fa-chart-bar me-3"></i>
                        <span>Laporan</span>
                    </a>
                </li>
                
                <!-- Profile Section for Admin -->
                <li class="nav-item mb-2 mt-3">
                    <div class="nav-section-header px-3 py-2">
                        <small class="text-light opacity-75 fw-bold">PROFIL</small>
                    </div>
                </li>
                
                <li class="nav-item mb-1">
                    <a class="nav-link <?php echo e(request()->routeIs('profile.*') ? 'active' : ''); ?>"
                       href="<?php echo e(route('profile.index')); ?>">
                        <i class="fas fa-user me-3"></i>
                        <span>Profil Saya</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>

        <!-- Logout Button -->
        <div class="mt-auto px-3 pb-3">
            <form action="<?php echo e(route('auth.logout')); ?>" method="post"
                onsubmit="return confirm('Apakah anda yakin ingin keluar?')">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button class="btn btn-outline-light btn-sm w-100 logout-btn">
                    <i class="fas fa-sign-out-alt me-2"></i>
                    Keluar
                </button>
            </form>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\projek 1\absensi-project-main\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>